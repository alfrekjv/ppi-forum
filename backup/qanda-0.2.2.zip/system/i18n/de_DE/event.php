<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'invalid_subject'  => 'Der Versuch, das ungültige Subjekt %s an %s anzuhängen, ist fehlgeschlagen. Subjekte müssen die Klasse Event_Subject erweitern.',
	'invalid_observer' => 'Der Versuch, den ungültigen Beobachter %s an %s anzuhängen, ist fehlgeschlagen. Beobachter müssen die Klasse Event_Observer erweitern.',
);
