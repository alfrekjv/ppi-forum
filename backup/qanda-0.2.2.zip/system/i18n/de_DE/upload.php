<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'not_writable' => 'Das Verzeichnis für hochgeladene Dateien, %s, ist nicht beschreibbar.',
);