<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'general_error' => 'Si è verificato un errore durante l\'invio del messaggio di posta elettronica.'
);