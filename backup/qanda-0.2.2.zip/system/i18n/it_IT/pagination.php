<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'undefined_group' => 'Il gruppo %s non è stato definito nel file di configurazione per la paginazione.',
	'page'            => 'pagina',
	'pages'           => 'pagine',
	'item'            => 'elemento',
	'items'           => 'elementi',
	'of'              => 'di',
	'first'           => 'primo',
	'last'            => 'ultimo',
	'previous'        => 'precedente',
	'next'            => 'successivo',
);
