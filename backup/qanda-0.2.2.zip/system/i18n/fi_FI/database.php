<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'undefined_group'       => 'Ryhmää %s ei ole määritelty asetuksissa.',
	'error'                 => 'SQL-virhe: %s',
	'connection'            => 'Virhe yhdistettäessä tietokantaan: %s',
	'invalid_dsn'           => 'Antamasi DSN ei ole hyväksyttävä: %s',
	'must_use_set'          => 'SET tulee olla annettu kyselyssä.',
	'must_use_where'        => 'WHERE tulee olla annettu kyselyssä.',
	'must_use_table'        => 'Tietokantataulu tulee olla annettu kyselyssä.',
	'table_not_found'       => 'Taulua %s ei löydy tietokannassa.',
	'not_implemented'       => 'Kutsumasi metodi, %s, ei ole tuettu tällä ajurilla.',
	'result_read_only'      => 'Kyselyn tuloksia voidaan vain lukea.'
);