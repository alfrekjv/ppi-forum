<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'file_not_found' => 'Podany plik %s, nie został znaleziony. Sprawdź czy plik istnieje używając file_exists() przed wywołaniem.',
	'requires_GD2'   => 'Biblioteka Captcha wymaga biblioteki graficznej GD2 z obsługą FreeType. Więcej informacji pod: http://php.net/gd_info.',
);
