<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'undefined_group'   => 'Brak definicji grupy %s w konfiguracji.',
	'requires_mcrypt'   => 'Aby użyć biblioteki szyfrowania, należy włączyć mcrypt w konfiguracji PHP.',
	'no_encryption_key' => 'Aby użyć biblioteki szyfrowania, należy zdefiniować klucz szyfrujący w pliku konfiguracji.',
);
