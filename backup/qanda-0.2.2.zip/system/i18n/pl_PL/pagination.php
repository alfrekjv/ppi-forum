<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'undefined_group' => 'Grupa %s nie została zdefiniowana w konfiguracji paginacji.',
	'page'     => 'strona',
	'pages'    => 'stron',
	'item'     => 'element',
	'items'    => 'elementów',
	'of'       => 'z',
	'first'    => 'pierwsza',
	'last'     => 'ostatnia',
	'previous' => 'poprzednia',
	'next'     => 'następna',
);
