<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'general_error' => 'Une erreur est survenue lors de l\'envoi du message.'
);
