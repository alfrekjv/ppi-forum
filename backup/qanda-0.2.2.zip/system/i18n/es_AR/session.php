<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'invalid_session_name' => 'El parametro session_name, %s, no es valido. Solo debe contener caracteres alfanumericos y guiones bajos. También al menos uno debe de ser una letra.',
);