<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang['query_methods_not_allowed'] = 'No esta permitido utilizar metodos de Query mediante ORM.';
