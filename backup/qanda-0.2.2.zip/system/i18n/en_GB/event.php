<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'invalid_subject'  => 'Attempt to attach invalid subject %s to %s failed: Subjects must extend the Event_Subject class',
	'invalid_observer' => 'Attempt to attach invalid observer %s to %s failed: Observers must extend the Event_Observer class',
);
