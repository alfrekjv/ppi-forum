<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'general_error' => 'An error occurred while sending the email message.'
);