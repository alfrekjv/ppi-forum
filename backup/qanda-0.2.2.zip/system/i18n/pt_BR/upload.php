<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
    'not_writable' => 'O diretório de destino, %s, parece não ter permissão de escrita.',
);
