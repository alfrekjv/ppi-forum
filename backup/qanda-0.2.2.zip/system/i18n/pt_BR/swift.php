<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'general_error' => 'Um erro ocorreu enquanto a imagem estava sendo enviada.'
);
